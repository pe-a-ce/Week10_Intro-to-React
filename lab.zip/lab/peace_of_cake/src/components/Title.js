
const Title = () => {

    return(
    <h1 className="Header">Welcome to a Peace of Cake!!</h1>
    )
}

export default Title;