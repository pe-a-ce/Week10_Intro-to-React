
const Navigation = () => {

    return(
        <div className="Navigation">
            <a href="#home">Home</a>
            <a href="#news">Recipes</a>
            <a href="#about">About</a>
        </div>
    )
}

export default Navigation;